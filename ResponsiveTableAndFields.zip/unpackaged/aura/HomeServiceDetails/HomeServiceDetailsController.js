({
    handleApplicationEvent : function(component, event) {
        var homeCleaning = event.getParam("homeCleaning");
        var homeCleaningImg = event.getParam("homeCleaningImg");
        var acCleaning = event.getParam("acCleaning");
        var acDuctCleaning = event.getParam("acDuctCleaning");
        var poolCleaning = event.getParam("poolCleaning");
        var tankCleaning = event.getParam("tankCleaning");
        var maintenance = event.getParam("maintenance");
        component.set("v.homeCleaning", homeCleaning);
        component.set("v.homeCleaningImg", homeCleaningImg);
        component.set("v.acCleaning", acCleaning);
        component.set("v.acDuctCleaning", acDuctCleaning);
        component.set("v.poolCleaning", poolCleaning);
        component.set("v.tankCleaning", tankCleaning);
        component.set("v.maintenance", maintenance);
    }
})