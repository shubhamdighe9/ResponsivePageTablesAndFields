({
	handleSelect : function(component, event, helper) {
         var selected = event.getParam('name');
        console.log("selected " + selected );
		if (selected === 'Parking_request') {
            var appEvent = $A.get("e.c:AmenitiesEvent");
            appEvent.setParams({
                "parkingRequest" : true,
                "allRequest" : false,
               /* "swimming request" : this will hold swimming request form
                "club house request" : false, this will hold club house request form
                "Tennis court request" : false	this will hold tennis court requests,	
               "All request" : false, this will hold list of all request with amenitiy time filter request*/
            });
            appEvent.fire();
        }
        if (selected === 'all_Request') {
            var appEvent = $A.get("e.c:AmenitiesEvent");
            appEvent.setParams({
                "parkingRequest" : false,
                "allRequest" : true,
               /* "swimming request" : this will hold swimming request form
                "club house request" : false, this will hold club house request form
                "Tennis court request" : false	this will hold tennis court requests,	
               "All request" : false, this will hold list of all request with amenitiy time filter request*/
            });
            appEvent.fire();
        }
	}
})