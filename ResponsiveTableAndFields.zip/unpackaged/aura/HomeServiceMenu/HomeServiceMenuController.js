({
    handleSelect: function(component, event, helper) {
        var selected = event.getParam('name');
        if (selected === 'Cleaning') {
            var counter = component.get('v.CleaningCounter');
            counter++;
            component.set('v.CleaningCounter', counter);
            if(counter % 2 == 0){
                component.set('v.showCleaningItem', false);
            }else{
                component.set('v.showCleaningItem', true);
                component.set('v.maintenanceItem', false);
                component.set('v.helpItem', false);
            }
        }else  if (selected === 'Maintenance') {
            var counter = component.get('v.maintenanceCounter');
            counter++;
            component.set('v.maintenanceCounter', counter);
            if(counter % 2 == 0){
                component.set('v.maintenanceItem', false);
            }else{
                component.set('v.maintenanceItem', true);
                component.set('v.showCleaningItem', false);
                component.set('v.helpItem', false);
            }
        }else  if (selected === 'Home_Help') {
            var counter = component.get('v.helpCounter');
            counter++;
            component.set('v.helpCounter', counter);
            if(counter % 2 == 0){
                component.set('v.helpItem', false);
            }else{
                component.set('v.helpItem', true);
                component.set('v.showCleaningItem', false);
                component.set('v.maintenanceItem', false);
            }
        }
        
        if (selected === 'Home_Cleaning') {
            
            var appEvent = $A.get("e.c:HomeServiceEvent");
            appEvent.setParams({
                "homeCleaning" : true,
                "homeCleaningImg" : false,
                "acCleaning" : false,
                "poolCleaning" : false,
                "acDuctCleaning" : false,
                "tankCleaning" : false,
                "maintenance" : false
            });
            appEvent.fire();
            
        }else  if (selected === 'AC_Cleaning') {
            var appEvent = $A.get("e.c:HomeServiceEvent");
            appEvent.setParams({
                "homeCleaning" : false,
                "homeCleaningImg" : false,
                "acCleaning" : true,
                "poolCleaning" : false,
                "acDuctCleaning" : false,
                "tankCleaning" : false,
                "maintenance" : false
            });
            appEvent.fire();
            
        }else  if (selected === 'AC_Duct_Cleaning') {
            var appEvent = $A.get("e.c:HomeServiceEvent");
            appEvent.setParams({
                "homeCleaning" : false,
                "homeCleaningImg" : false,
                "acCleaning" : false,
                "poolCleaning" : false,
                "acDuctCleaning" : true,
                "tankCleaning" : false,
                "maintenance" : false
            });
            appEvent.fire();
            
        }else  if (selected === 'Pool_Cleaning') {
            var appEvent = $A.get("e.c:HomeServiceEvent");
            appEvent.setParams({
                "homeCleaning" : false,
                "homeCleaningImg" : false,
                "acCleaning" : false,
                "poolCleaning" : true,
                "acDuctCleaning" : false,
                "tankCleaning" : false,
                "maintenance" : false
            });
            appEvent.fire();
            
        }else  if (selected === 'Water_Tank_Cleaning') {
            var appEvent = $A.get("e.c:HomeServiceEvent");
            appEvent.setParams({
                "homeCleaning" : false,
                "homeCleaningImg" : false,
                "acCleaning" : false,
                "poolCleaning" : false,
                "acDuctCleaning" : false,
                "tankCleaning" : true,
                "maintenance" : false
            });
            appEvent.fire();
        }/*else  if (selected === 'Maintenance') {
            var appEvent = $A.get("e.c:HomeServiceEvent");
            appEvent.setParams({
                "homeCleaning" : false,
                "homeCleaningImg" : false,
                "acCleaning" : false,
                "poolCleaning" : false,
                "acDuctCleaning" : false,
                "tankCleaning" : false,
                "maintenance" : true
            });
            appEvent.fire();
        }*/
    }, 
})