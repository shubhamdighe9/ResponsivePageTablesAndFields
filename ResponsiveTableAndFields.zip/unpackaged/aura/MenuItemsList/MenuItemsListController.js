({
    serviceRequestSelected : function(component, event, helper) {
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({ "url": $A.get("$Label.c.CommunityURL")+"service-request" });   // Pass your community URL
        urlEvent.fire(); 
        
    },
    homeServiceSelected : function(component, event, helper) {
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({ "url": $A.get("$Label.c.CommunityURL")+"home-service" });   // Pass your community URL
        urlEvent.fire(); 
        
    },
    amenitySelected : function(component, event, helper) {
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({ "url": $A.get("$Label.c.CommunityURL")+"amenities" });   // Pass your community URL
        urlEvent.fire(); 
        
    },
    offersSelected : function(component, event, helper) {
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({ "url": $A.get("$Label.c.CommunityURL")+"offers-and-attractions" });   // Pass your community URL
        urlEvent.fire(); 
        
    },
    propertySelected : function(component, event, helper) {
        
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({ "url": $A.get("$Label.c.CommunityURL")+"my-properties" });   // Pass your community URL
        urlEvent.fire(); 
        
    }
})